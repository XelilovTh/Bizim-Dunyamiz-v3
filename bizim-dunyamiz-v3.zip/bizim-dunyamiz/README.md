# Bizim Dünyamız — v3

Vanilla HTML/CSS/JS ilə sıfırdan yenilənmiş Fidan & Təhmaz layihəsi.

## Məqsəd
Canva-dakı vizual dili mümkün qədər qoruyaraq köhnə tətbiqin funksional məntiqini daha modul, mobil-uyğun və gələcəkdə React-a daşınması asan formada yenidən qurmaq.

## Struktur
- `index.html` — yalnız UI skeleti
- `css/` — dizayn, responsive və komponent stilləri
- `js/config/` — tətbiq konfiqurasiyası
- `js/state/` — mərkəzi state
- `js/services/` — API, GitHub, Cloudinary kimi xarici servislər
- `js/features/` — auth, gallery, letters, music, admin, surprises
- `js/components/` — UI komponentləri üçün genişlənmə sahəsi
- `js/utils/` — DOM və format köməkçiləri
- `api/` — serverless backend və Telegram bot
- `data/` — məlumat modelinə dair sənədlər

## GitHub data model
- `photos_list.json`
- `music_list.json`
- `letters/*.txt`
- `blocked_ips.json`

## Environment
`.env.example`-i `.env` kimi kopyala və real dəyərləri əlavə et. Secretlər frontendə qoyulmamalıdır.

## Vercel
`api/proxy.js` və `api/bot.js` serverless endpoint kimi işləyir. Telegram webhook-u `/api/bot` endpointinə yönləndirilə bilər.

## Qeyd
Cloudinary browser upload üçün unsigned upload preset istifadə edir. Silmə əməliyyatları isə backend proxy üzərindən gedir.

## Gələcək React keçidi
`features/`, `services/` və `state/` qatları React komponentlərinə demək olar ki, birbaşa xəritələnə bilər.
