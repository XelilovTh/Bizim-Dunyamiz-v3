# Data

GitHub repository-də saxlanan canlı məlumatlar üçün bu qovluq yalnız sənədləşdirmə məqsədlidir.

photos_list.json elementləri: `{ name, public_id, download_url, created_at }`
music_list.json elementləri: `{ name, public_id, download_url, artist?, created_at }`
blocked_ips.json: string array
letters/: plain text files
