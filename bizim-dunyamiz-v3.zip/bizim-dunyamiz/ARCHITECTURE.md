# Arxitektura

UI → feature layer → services → serverless API → GitHub / Cloudinary / Telegram.

## Auth
İstifadəçi şifrəsi `check_password` ilə serverdə yoxlanılır. Admin statusu hazırda sessiya daxilində saxlanır və köhnə layihədəki model qəsdən qorunur.

## Gallery
Cloudinary URL + public_id GitHub `photos_list.json`-da saxlanılır. Frontend siyahını oxuyur, lazy loading ilə şəkilləri göstərir.

## Music
Musiqi Cloudinary video resource type ilə saxlanılır; `music_list.json` metadata saxlayır. Player HTMLAudioElement üzərində qurulub.

## Letters
Məktublar GitHub-da `.txt` fayllarıdır.

## Telegram
Şəkil → Cloudinary → photos_list.json; musiqi → Cloudinary → music_list.json; mətn → letters/*.txt; `/stats` → statistika.

## AI-friendly qayda
Yeni funksiya əlavə ediləndə mümkün qədər bir feature faylına, xarici servis əlaqəsi isə `services/` qatına yerləşdirilməlidir. `app.js` yalnız orchestration etməlidir.
